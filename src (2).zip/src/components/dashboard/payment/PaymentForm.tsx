"use client";

import { useState } from "react";
import toast from "react-hot-toast";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectItem,
  SelectTrigger,
  SelectContent,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

type User = {
  id: string;
  name: string;
  role: "student" | "main_admin" | "parallel_admin";
};

export default function PaymentForm({
  currentUser,
  users,
  onSuccess,
  onError,
}: {
  currentUser: User;
  users: User[];
  onSuccess: () => void;
  onError: (msg: string) => void;
}) {
  const isAdmin =
    currentUser.role === "main_admin" || currentUser.role === "parallel_admin";

  const [selectedUser, setSelectedUser] = useState(
    isAdmin ? "" : currentUser.id
  );
  const [amount, setAmount] = useState("");
  const [notes, setNotes] = useState("");
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);

  async function uploadReceipt(): Promise<string | null> {
    if (!receiptFile) return null;

    const form = new FormData();
    form.append("file", receiptFile);

    const resp = await fetch("/api/contributions/upload-receipt", {
      method: "POST",
      body: form,
    });

    const data = await resp.json();
    if (!resp.ok) {
      onError(data.error || "Upload failed");
      return null;
    }
    return data.publicUrl;
  }

  async function handleAdminAdd() {
    if (!selectedUser) return onError("Please select a user");
    if (!amount) return onError("Enter valid amount");

    setLoading(true);

    try {
      const body: any = {
        user_id: selectedUser,
        amount: Number(amount),
        type: "manual",
        notes,
        logged_by_admin_id: currentUser.id,
      };

      if (receiptFile) {
        const uploadedUrl = await uploadReceipt();
        if (uploadedUrl) body.receipt_url = uploadedUrl;
      }

      const resp = await fetch("/api/contributions/add", {
        method: "POST",
        body: JSON.stringify(body),
      });

      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error);

      onSuccess();
      setAmount("");
      setNotes("");
      setReceiptFile(null);
      setSelectedUser(isAdmin ? "" : currentUser.id);
    } catch (err: any) {
      onError(err.message || "Failed");
    } finally {
      setLoading(false);
    }
  }

  async function handleOffline() {
    if (!amount) return onError("Enter amount");

    setLoading(true);
    try {
      const body = {
        user_id: currentUser.id,
        amount: Number(amount),
        type: "offline",
        notes,
      };

      const resp = await fetch("/api/contributions/add", {
        method: "POST",
        body: JSON.stringify(body),
      });

      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error);

      onSuccess();
      setAmount("");
      setNotes("");
    } catch (err: any) {
      onError(err.message || "Error");
    } finally {
      setLoading(false);
    }
  }

  async function handleOnline() {
    if (!amount) return onError("Amount required");

    setLoading(true);

    try {
      // create Razorpay order
      const create = await fetch("/api/razorpay/create-order", {
        method: "POST",
        body: JSON.stringify({
          amount: Number(amount) * 100,
          notes: { user_id: currentUser.id },
        }),
      });

      const order = await create.json();
      if (!create.ok) throw new Error(order.error);

      const options = {
        key: order.key_id,
        amount: order.amount,
        currency: order.currency,
        name: "Farewell Contributions",
        order_id: order.id,
        prefill: {
          name: currentUser.name,
        },
        handler: async (response: any) => {
          const verify = await fetch("/api/razorpay/verify-and-capture", {
            method: "POST",
            body: JSON.stringify({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              selected_user: currentUser.id,
              metadata: {
                amount: Number(amount),
                notes,
              },
            }),
          });

          const v = await verify.json();
          if (!verify.ok) throw new Error(v.error);

          onSuccess();
          setAmount("");
          setNotes("");
        },
      };

      // @ts-ignore
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err: any) {
      onError(err.message || "Razorpay failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="shadow-xl rounded-2xl">
      <CardHeader>
        <CardTitle>Payment Options</CardTitle>
      </CardHeader>

      <CardContent>
        <Tabs
          defaultValue={isAdmin ? "admin_add" : "online"}
          className="space-y-6"
        >
          <TabsList className="grid grid-cols-2 w-full">
            {isAdmin ? (
              <>
                <TabsTrigger value="admin_add">Admin Add</TabsTrigger>
                <TabsTrigger value="online">Online Payment</TabsTrigger>
              </>
            ) : (
              <>
                <TabsTrigger value="online">Online</TabsTrigger>
                <TabsTrigger value="offline">Offline</TabsTrigger>
              </>
            )}
          </TabsList>

          {/* Admin Add */}
          {isAdmin && (
            <TabsContent value="admin_add" className="space-y-4">
              <Select
                onValueChange={(v) => setSelectedUser(v)}
                value={selectedUser}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select user" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((u) => (
                    <SelectItem key={u.id} value={u.id}>
                      {u.name} ({u.role})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Input
                type="number"
                placeholder="Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />

              <Textarea
                placeholder="Notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />

              <Input
                type="file"
                onChange={(e) =>
                  setReceiptFile(e.target.files ? e.target.files[0] : null)
                }
              />

              <Button
                className="w-full mt-4"
                disabled={loading}
                onClick={handleAdminAdd}
              >
                {loading ? "Processing..." : "Submit"}
              </Button>
            </TabsContent>
          )}

          {/* Online (student + admin) */}
          <TabsContent value="online" className="space-y-4">
            <Input
              type="number"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <Textarea
              placeholder="Notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />

            <Button
              className="w-full mt-4"
              disabled={loading}
              onClick={handleOnline}
            >
              {loading ? "Processing..." : "Pay Online"}
            </Button>
          </TabsContent>

          {/* Offline (student only) */}
          {!isAdmin && (
            <TabsContent value="offline" className="space-y-4">
              <Input
                type="number"
                placeholder="Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <Textarea
                placeholder="Reason / Notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />

              <Button
                className="w-full mt-4"
                disabled={loading}
                onClick={handleOffline}
              >
                {loading ? "Submitting..." : "Request Offline Payment"}
              </Button>
            </TabsContent>
          )}
        </Tabs>
      </CardContent>
    </Card>
  );
}
