// src/lib/contributions.server.ts
import type { Database } from "@/types/supabase";
import { createClient } from "@/lib/supabase/server";
import type { RealtimePostgresChangesPayload } from "@supabase/supabase-js";
import crypto from "crypto";

export type TxRow = Database["public"]["Tables"]["transactions"]["Row"];
export type TxInsert = Database["public"]["Tables"]["transactions"]["Insert"];

const RECEIPT_BUCKET = "receipts";
const RECEIPT_PREFIX = "receipts/";

/**
 * Returns authenticated user via server-side Supabase client.
 * Throws on unauthenticated or error.
 */
export async function getAuthenticatedUser() {
  const supabase = await createClient();
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    throw new Error("Not authenticated");
  }
  return user;
}

/** Verify whether a user is admin for any farewell (main_admin or parallel_admin) */
export async function isUserAdmin(userId: string): Promise<boolean> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("farewell_participants")
    .select("role")
    .eq("user_id", userId)
    .limit(1)
    .maybeSingle();

  if (error) throw error;
  if (!data) return false;
  return data.role === "main_admin" || data.role === "parallel_admin";
}

/**
 * Insert a transaction (server-side).
 * If logged_by_admin_id provided, the authenticated user must be that admin.
 */
export async function serverAddTransaction(payload: {
  user_id: string;
  amount: number | string;
  type?: string | null;
  notes?: string | null;
  receipt_url?: string | null;
  logged_by_admin_id?: string | null;
}) {
  const authUser = await getAuthenticatedUser();
  const supabase = await createClient();

  if (payload.logged_by_admin_id) {
    if (!(await isUserAdmin(authUser.id))) {
      throw new Error("Unauthorized: admin privileges required");
    }
    if (payload.logged_by_admin_id !== authUser.id) {
      throw new Error("logged_by_admin_id must match authenticated user");
    }
  }

  const insert: TxInsert = {
    user_id: payload.user_id,
    amount: String(payload.amount),
    type: payload.type ?? "online",
    notes: payload.notes ?? null,
    receipt_url: payload.receipt_url ?? null,
    logged_by_admin_id: payload.logged_by_admin_id ?? null,
    status:
      payload.logged_by_admin_id || payload.type === "online"
        ? "completed"
        : "pending",
  } as TxInsert;

  const { error } = await supabase.from("transactions").insert([insert]);
  if (error) throw error;
  return { success: true };
}

/**
 * Approve pending transaction (server-side). Only admins allowed.
 */
export async function serverApproveTransaction(transactionId: number) {
  const authUser = await getAuthenticatedUser();
  const supabase = await createClient();

  if (!(await isUserAdmin(authUser.id))) {
    throw new Error("Unauthorized: admin required");
  }

  const { error } = await supabase
    .from("transactions")
    .update({ status: "completed", logged_by_admin_id: authUser.id })
    .eq("id", transactionId);

  if (error) throw error;
  return { success: true };
}

/**
 * Upload receipt buffer to Supabase Storage and return public URL.
 * Assumes `createClient()` creates a server client with proper keys.
 */
export async function serverUploadReceipt(opts: {
  buffer: Buffer;
  filename: string;
  contentType?: string | null;
}) {
  const supabase = await createClient();
  const key = `${RECEIPT_PREFIX}${opts.filename}`;

  const { error } = await supabase.storage
    .from(RECEIPT_BUCKET)
    .upload(key, opts.buffer, {
      contentType: opts.contentType ?? undefined,
      upsert: false,
    });

  if (error) throw error;

  const {
    data: { publicUrl },
  } = supabase.storage.from(RECEIPT_BUCKET).getPublicUrl(key);
  return publicUrl;
}

/**
 * Create Razorpay order on server.
 */
export async function serverCreateRazorpayOrder(opts: {
  amountInPaisa: number;
  currency?: string;
  receipt?: string;
  notes?: Record<string, unknown>;
}) {
  const {
    amountInPaisa,
    currency = "INR",
    receipt = `receipt_${Date.now()}`,
    notes,
  } = opts;

  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret)
    throw new Error("Razorpay credentials not configured");

  const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");

  const resp = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount: amountInPaisa,
      currency,
      receipt,
      payment_capture: 1,
      notes: notes ?? {},
    }),
  });

  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`Razorpay order create failed: ${text}`);
  }

  const order = await resp.json();
  return {
    id: String(order.id),
    amount: Number(order.amount),
    currency: String(order.currency),
    key_id: keyId,
  } as { id: string; amount: number; currency: string; key_id: string };
}

/**
 * Verify Razorpay signature and persist transaction.
 */
export async function serverVerifyAndPersistRazorpay(opts: {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
  selected_user_id?: string | null;
  metadata?: { amount?: number; notes?: string | null } | null;
}) {
  const {
    razorpay_order_id,
    razorpay_payment_id,
    razorpay_signature,
    selected_user_id,
    metadata,
  } = opts;

  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keySecret) throw new Error("Razorpay secret not configured");

  const expected = crypto
    .createHmac("sha256", keySecret)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest("hex");

  if (expected !== razorpay_signature) {
    throw new Error("Invalid Razorpay signature");
  }

  const supabase = await createClient();

  const amountValue = metadata?.amount ?? 0;
  const notes = metadata?.notes ?? null;

  const insert: TxInsert = {
    user_id: selected_user_id ?? "",
    amount: String(amountValue),
    type: "online",
    status: "completed",
    notes,
    payment_gateway_id: razorpay_payment_id,
  } as TxInsert;

  const { error } = await supabase.from("transactions").insert([insert]);
  if (error) throw error;

  return { success: true };
}

/**
 * Typed realtime payload helper type (server usage example).
 */
export type RealtimePayload = RealtimePostgresChangesPayload<
  Database["public"]["Tables"]["transactions"]["Row"]
>;
