// src/types/supabase.ts
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string | null;
          username: string | null;
          avatar_url: string | null;
          updated_at: string | null;
        };
        Insert: {
          id: string;
          full_name?: string | null;
          username?: string | null;
          avatar_url?: string | null;
          updated_at?: string | null;
        };
        Update: {
          id?: string;
          full_name?: string | null;
          username?: string | null;
          avatar_url?: string | null;
          updated_at?: string | null;
        };
      };

      farewell_participants: {
        Row: {
          id: number;
          user_id: string;
          farewell_id: number;
          role: "student" | "main_admin" | "parallel_admin" | string;
          joined_at: string | null;
        };
        Insert: {
          user_id: string;
          farewell_id: number;
          role?: "student" | "main_admin" | "parallel_admin" | string;
          joined_at?: string | null;
        };
        Update: {
          user_id?: string;
          farewell_id?: number;
          role?: "student" | "main_admin" | "parallel_admin" | string;
          joined_at?: string | null;
        };
      };

      transactions: {
        Row: {
          id: number;
          farewell_id: number | null;
          user_id: string;
          recipient_user_id: string | null;
          amount: string; // numeric returned as string by Supabase JS
          total_amount: string | null;
          type: string | null;
          method: string | null;
          status: string | null;
          is_dummy: boolean | null;
          receipt_url: string | null;
          logged_by_admin_id: string | null;
          payment_gateway_id: string | null;
          currency: string | null;
          metadata: Json | null;
          notes: string | null;
          refunded_amount: string | null;
          parent_transaction_id: number | null;
          chargeback: boolean | null;
          created_at: string | null;
          updated_at: string | null;
        };
        Insert: {
          farewell_id?: number | null;
          user_id: string;
          recipient_user_id?: string | null;
          amount: string | number;
          total_amount?: string | number | null;
          type?: string | null;
          method?: string | null;
          status?: string | null;
          is_dummy?: boolean | null;
          receipt_url?: string | null;
          logged_by_admin_id?: string | null;
          payment_gateway_id?: string | null;
          currency?: string | null;
          metadata?: Json | null;
          notes?: string | null;
          refunded_amount?: string | number | null;
          parent_transaction_id?: number | null;
          chargeback?: boolean | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
        Update: {
          farewell_id?: number | null;
          user_id?: string;
          recipient_user_id?: string | null;
          amount?: string | number;
          total_amount?: string | number | null;
          type?: string | null;
          method?: string | null;
          status?: string | null;
          is_dummy?: boolean | null;
          receipt_url?: string | null;
          logged_by_admin_id?: string | null;
          payment_gateway_id?: string | null;
          currency?: string | null;
          metadata?: Json | null;
          notes?: string | null;
          refunded_amount?: string | number | null;
          parent_transaction_id?: number | null;
          chargeback?: boolean | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
  };
}
