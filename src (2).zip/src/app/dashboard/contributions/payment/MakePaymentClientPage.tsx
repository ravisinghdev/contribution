"use client";

import { useState, useEffect, useCallback } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import toast from "react-hot-toast";

import { useTransactionsRealtime } from "@/lib/realtime/useTransactionsRealtime";
import { txRowToView } from "@/lib/transactions/transform";

import type { Database } from "@/types/supabase";
import PaymentForm from "@/components/dashboard/payment/PaymentForm";
import SummaryCards from "@/components/dashboard/payment/SummarCard";
import TransactionTable from "@/components/dashboard/payment/TransactionsTable";

type TxRow = Database["public"]["Tables"]["transactions"]["Row"];
type TxView = ReturnType<typeof txRowToView>;

type User = {
  id: string;
  name: string;
  role: "student" | "main_admin" | "parallel_admin";
};

export default function MakePaymentClientPage({
  currentUser,
  users,
}: {
  currentUser: User;
  users: User[];
}) {
  const supabase = createClientComponentClient<Database>();

  const [rows, setRows] = useState<TxRow[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchInitial = useCallback(async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from("transactions")
      .select("*, profiles!inner(full_name)")
      .order("created_at", { ascending: false })
      .limit(200);

    if (error) {
      toast.error("Failed to fetch transactions");
      setLoading(false);
      return;
    }

    const mapped: TxRow[] = (data || []).map((r: any) => ({
      ...r,
      user_name: r.profiles?.full_name ?? null,
    }));

    setRows(mapped);
    setLoading(false);
  }, [supabase]);

  // realtime attach
  useTransactionsRealtime(supabase, setRows);

  useEffect(() => {
    fetchInitial();
  }, [fetchInitial]);

  const txView: TxView[] = rows.map(txRowToView);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-12">
      <SummaryCards loading={loading} transactions={txView} />

      {/* The main 3-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <PaymentForm
            currentUser={currentUser}
            users={users}
            onSuccess={() => toast.success("Payment successful")}
            onError={(msg) => toast.error(msg)}
          />
        </div>

        <TransactionTable
          currentUser={currentUser}
          transactions={txView}
          onApprove={() => toast.success("Approved")}
          onError={(msg) => toast.error(msg)}
        />
      </div>
    </div>
  );
}
