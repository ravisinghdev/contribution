import AnnouncementsClient from "./AnnouncementClient";

export default async function Page() {
  return <AnnouncementsClient />;
}
