// src/app/api/razorpay/create-order/route.ts
import { NextResponse } from "next/server";
import { serverCreateRazorpayOrder } from "@/lib/contributions.server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    // client must send amount in paisa as number
    const amount = body.amount;
    const currency = typeof body.currency === "string" ? body.currency : "INR";
    const receipt = typeof body.receipt === "string" ? body.receipt : undefined;
    const notes = typeof body.notes === "object" ? body.notes : undefined;

    if (typeof amount !== "number" || Number.isNaN(amount) || amount <= 0) {
      return NextResponse.json(
        { error: "Invalid amount (must be paisa integer number)" },
        { status: 400 }
      );
    }

    const order = await serverCreateRazorpayOrder({
      amountInPaisa: amount,
      currency,
      receipt,
      notes,
    });

    return NextResponse.json(order);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
