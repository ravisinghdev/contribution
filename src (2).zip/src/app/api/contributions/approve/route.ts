// src/app/api/contributions/approve/route.ts
import { NextResponse } from "next/server";
import { serverApproveTransaction } from "@/lib/contributions.server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const id = typeof body.id === "number" ? body.id : Number(body.id);

    if (!id || Number.isNaN(id)) {
      return NextResponse.json(
        { error: "Invalid or missing id" },
        { status: 400 }
      );
    }

    await serverApproveTransaction(id);

    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
