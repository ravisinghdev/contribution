"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client"; // Our client-side helper
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function AuthForm() {
  const [loading, setLoading] = useState<boolean>(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");

  const router = useRouter();
  const supabase = createClient();

  // --- Sign In Handler ---
  const handleSignIn = async (e: React.FormEvent) => {
    try {
      e.preventDefault();
      setLoading(true);
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast.error(error.message);
      } else {
        toast.success("Logged in successfully!");
        router.refresh(); // This re-validates the session on the server
        router.push("/dashbaord"); // Redirect to the home/dashboard page
      }
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  // --- Sign Up Handler ---
  const handleSignUp = async (e: React.FormEvent) => {
    try {
      e.preventDefault();
      setLoading(true);

      // Check if passwords are strong enough (optional but recommended)
      if (password.length < 6) {
        toast.error("Password must be at least 6 characters long.");
        return;
      }

      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName, username: username },
          emailRedirectTo: `${location.origin}/auth/callback`,
        },
      });

      if (error) {
        toast.error(error.message);
      } else {
        router.push(`/check-email?email=${encodeURIComponent(email)}`);
      }
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  // --- Google (or other OAuth) Handler ---
  const handleGoogleSignIn = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: `${location.origin}/auth/callback`,
        },
      });
      if (error) toast.error(error.message);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl">Login / Sign Up</CardTitle>
        <CardDescription>
          Enter your credentials or sign up for a new account.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="signin" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>

          {/* --- Sign In Tab --- */}
          <TabsContent value="signin">
            <form onSubmit={handleSignIn}>
              <div className="grid gap-4 mt-4">
                <div className="grid gap-2">
                  <Label htmlFor="email-signin">Email</Label>
                  <Input
                    id="email-signin"
                    type="email"
                    placeholder="m@example.com"
                    required
                    onChange={(e) => setEmail(e.target.value)}
                    value={email}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="password-signin">Password</Label>
                  <Input
                    id="password-signin"
                    type="password"
                    required
                    onChange={(e) => setPassword(e.target.value)}
                    value={password}
                  />
                </div>
                <Button type="submit" className="w-full">
                  {loading ? (
                    <>
                      <Spinner />
                      Loging in...
                    </>
                  ) : (
                    "Login"
                  )}
                </Button>
              </div>
            </form>
          </TabsContent>

          {/* --- Sign Up Tab --- */}
          <TabsContent value="signup">
            <form onSubmit={handleSignUp}>
              <div className="grid gap-4 mt-4">
                <div className="grid gap-2">
                  <Label htmlFor="full_name-signup">Full Name</Label>
                  <Input
                    id="full_name-signup"
                    type="text"
                    placeholder="Your Name"
                    required
                    onChange={(e) => setFullName(e.target.value)}
                    value={fullName}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="username-signup">
                    Username (e.g., your_name_123)
                  </Label>
                  <Input
                    id="username-signup"
                    type="text"
                    placeholder="your_name_123"
                    required
                    onChange={(e) => setUsername(e.target.value)}
                    value={username}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email-signup">Email</Label>
                  <Input
                    id="email-signup"
                    type="email"
                    placeholder="m@example.com"
                    required
                    onChange={(e) => setEmail(e.target.value)}
                    value={email}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="password-signup">
                    Password (min. 6 chars)
                  </Label>
                  <Input
                    id="password-signup"
                    type="password"
                    required
                    onChange={(e) => setPassword(e.target.value)}
                    value={password}
                  />
                </div>
                <Button type="submit" className="w-full">
                  {loading ? (
                    <>
                      <Spinner />
                      Sigining up...
                    </>
                  ) : (
                    "Sign Up"
                  )}
                </Button>
              </div>
            </form>
          </TabsContent>
        </Tabs>

        {/* --- Social Login Divider --- */}
        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">
              Or continue with
            </span>
          </div>
        </div>

        {/* --- Google Button --- */}
        <Button
          variant="outline"
          className="w-full"
          onClick={handleGoogleSignIn}
        >
          {/* You can add a Google icon here */}
          Continue with Google
        </Button>
      </CardContent>
    </Card>
  );
}
