"use client";

import { useTransition } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { ChevronsUpDown, Check, Loader2, PartyPopper } from "lucide-react";
import { switchFarewell } from "@/app/dashboard/actions"; // Our Server Action
import type { Farewell } from "@/app/dashboard/layout"; // Our new Type

interface FarewellSwitcherProps {
  allFarewells: Farewell[];
  activeFarewell: Farewell;
}

export function FarewellSwitcher({
  allFarewells,
  activeFarewell,
}: FarewellSwitcherProps) {
  const [isPending, startTransition] = useTransition();

  const handleSwitch = (farewellId: string) => {
    // Use startTransition to call the server action
    // This keeps the UI interactive
    startTransition(() => {
      switchFarewell(farewellId);
    });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="flex items-center gap-2 text-lg font-semibold px-2"
        >
          {isPending ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <PartyPopper className="h-5 w-5 text-pink-400" />
          )}
          <span className="truncate max-w-[200px]">{activeFarewell.name}</span>
          <ChevronsUpDown className="h-4 w-4 opacity-60" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64" align="start">
        <DropdownMenuLabel>Select Farewell</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {allFarewells.map((farewell) => (
          <DropdownMenuItem
            key={farewell.id}
            disabled={isPending}
            onSelect={() => handleSwitch(farewell.id.toString())}
            className="flex justify-between"
          >
            <div>
              <p className="font-medium">{farewell.name}</p>
              <p className="text-xs text-muted-foreground">
                {farewell.event_year}
              </p>
            </div>
            {farewell.id === activeFarewell.id && (
              <Check className="h-4 w-4 text-primary" />
            )}
          </DropdownMenuItem>
        ))}
        {/* We can add a "Create New" link here later */}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
