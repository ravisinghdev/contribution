"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Menu, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useSidebar } from "./SidebarContext";
import NotificationDropdown from "./NotificationDropdown";
import ProfileDropdown from "./ProfileDropdown";
import { motion, AnimatePresence } from "framer-motion";
import { ThemeToggler } from "@/components/theme/ThemeToggler";
import SearchBar from "./SearchBar";
import { FarewellSwitcher } from "./FarewellSwitcher"; // <-- 1. Import the new switcher
import type { Farewell } from "@/app/dashboard/layout"; // <-- 2. Import the type

// 3. Define the new props it will receive
interface NavbarProps {
  user: {
    full_name: string;
    avatar_url: string | null;
  };
  email: string;
  allFarewells: Farewell[];
  activeFarewell: Farewell;
}

export default function Navbar({
  user,
  email,
  allFarewells,
  activeFarewell,
}: NavbarProps) {
  // <-- 4. Accept the new props

  const { toggle } = useSidebar();
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <nav className="h-14 flex items-center justify-between px-4 sm:px-6 bg-background/95 backdrop-blur border-b">
        {/* left: menu + brand */}
        <div className="flex items-center gap-3">
          <button
            className="sm:hidden p-2 rounded-md hover:bg-muted transition-colors"
            onClick={toggle}
            aria-label="Toggle sidebar"
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* 5. ADD THE SWITCHER
            We've replaced the "Farewell App" text with our new component
          */}
          <FarewellSwitcher
            allFarewells={allFarewells}
            activeFarewell={activeFarewell}
          />

          <div className="hidden md:flex items-center ml-6 relative w-72">
            <SearchBar />
          </div>
        </div>

        {/* right: actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="hidden sm:flex items-center gap-3">
            <ThemeToggler />
          </div>

          <button
            className="md:hidden p-2 rounded-md hover:bg-muted transition-colors"
            onClick={() => setMobileSearchOpen((s) => !s)}
            aria-label="Open search"
          >
            <Search className="h-5 w-5" />
          </button>

          <NotificationDropdown />
          <ProfileDropdown user={user} email={email} />
        </div>
      </nav>

      {/* mobile search dropdown (no changes) */}
      <AnimatePresence>
        {mobileSearchOpen && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18 }}
            className="md:hidden bg-background border-b px-4 py-3"
          >
            <div className="flex items-center gap-2">
              <Search className="h-5 w-5 text-muted-foreground" />
              <Input
                aria-label="Mobile search"
                placeholder="Search memories, people..."
                className="h-9"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
