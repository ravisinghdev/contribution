
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { AddPaymentForm } from "./AddPaymentForm"; // We'll create this next
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { cookies } from "next/headers";
import toast from "react-hot-toast";

// Define a type for our participants list
export type Participant = {
  value: string; // user_id
  label: string; // full_name
};

export default async function AddPaymentPage() {
  const cookieStore =await cookies();
  const supabase = await createClient();

  // 1. Get User
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    redirect("/login");
  }

  // 2. Get user's current farewell and role
  const activeFarewellId = cookieStore.get("active_farewell_id")?.value;

  if (!activeFarewellId) {
    // This should be impossible if the layout is working, but it's a good safeguard
    toast.error("No active farewell selected.");
    redirect("/dashboard");
  }

  const { data: participation } = await supabase
    .from("farewell_participants")
    .select("role")
    .eq("user_id", user.id)
    .eq("farewell_id", activeFarewellId) // Check for the active farewell
    .limit(1)
    .single();

  if (!participation) {
    // Safeguard
    redirect("/dashboard/welcome");
  }

  const { role } = participation;
  const isAdmin = role === "main_admin" || role === "parallel_admin";
  let participantsList: Participant[] = [];

  // 3. If user is an admin, fetch all participants in this farewell
  if (isAdmin) {
    const { data: participantsData } = await supabase
      .from("farewell_participants")
      .select("user_id, profiles ( full_name )") // Fetch user_id and the related profile's name
      .eq("farewell_id", activeFarewellId);

    if (participantsData) {
      participantsList = participantsData.map((p) => ({
        value: p.user_id,
        label: p.profiles?.full_name || "Unknown User",
      }));
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="bg-black/20 backdrop-blur-lg border-white/20 text-white">
        <CardHeader>
          <CardTitle>Log a New Contribution</CardTitle>
          <CardDescription className="text-white/80">
            {isAdmin
              ? "You can log your own payment or a cash payment for another student."
              : "Complete your contribution for the farewell event."}
          </CardDescription>
        </CardHeader>
        <AddPaymentForm
          currentUserId={user.id}
          activeFarewellId={Number(activeFarewellId)}
          isAdmin={isAdmin}
          participants={participantsList} // Pass the list (it's empty for non-admins)
        />
      </Card>
    </div>
  );
}
