// app/dashboard/contributions/add/AddPaymentForm.tsx
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { toast } from 'react-hot-toast'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { CardContent } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { Loader2, Check, ChevronsUpDown } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Participant } from './page' // Import the type from our server page

// Define the props we're getting from the Server Page
interface AddPaymentFormProps {
  currentUserId: string
  activeFarewellId: number
  isAdmin: boolean
  participants: Participant[]
}

export function AddPaymentForm({
  currentUserId,
  activeFarewellId,
  isAdmin,
  participants,
}: AddPaymentFormProps) {
  const router = useRouter()
  const supabase = createClient()

  // Form State
  const [amount, setAmount] = useState<number | ''>('')
  const [method, setMethod] = useState<'online' | 'cash'>(isAdmin ? 'cash' : 'online')
  const [selectedUserId, setSelectedUserId] = useState<string>(currentUserId) // Defaults to self
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [openUserSearch, setOpenUserSearch] = useState(false)
  
  // This is the user ID that will be stored in the 'user_id' column
  const targetUserId = (isAdmin && method === 'cash') ? selectedUserId : currentUserId

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!amount || amount <= 0) {
      toast.error('Please enter a valid amount.')
      return
    }
    setIsSubmitting(true)

    const { error } = await supabase.from('transactions').insert({
      farewell_id: activeFarewellId,
      user_id: targetUserId,
      amount: amount,
      type: 'contribution',
      method: method,
      status: 'successful', // We'll assume successful for now
      // This is for your transparency feature:
      logged_by_admin_id: (isAdmin && method === 'cash') ? currentUserId : null,
    })

    if (error) {
      toast.error(error.message)
      setIsSubmitting(false)
    } else {
      toast.success('Payment logged successfully!')
      // Redirect to the history page so they can see their new payment
      router.push('/dashboard/contributions/history')
    }
    // We don't setIsSubmitting(false) on success because we're navigating away
  }

  return (
    <CardContent>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* --- Admin-Only Fields --- */}
        {isAdmin && (
          <>
            <div className="space-y-2">
              <Label htmlFor="method" className="text-white/80">Payment Method</Label>
              <Select
                value={method}
                onValueChange={(value: 'online' | 'cash') => setMethod(value)}
              >
                <SelectTrigger id="method">
                  <SelectValue placeholder="Select method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Log Cash Payment (for others)</SelectItem>
                  <SelectItem value="online">Pay Online (for myself)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Show user search *only* if admin is logging cash */}
            {method === 'cash' && (
              <div className="space-y-2">
                <Label className="text-white/80">For Which Student?</Label>
                <Popover open={openUserSearch} onOpenChange={setOpenUserSearch}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={openUserSearch}
                      className="w-full justify-between"
                    >
                      {selectedUserId
                        ? participants.find((p) => p.value === selectedUserId)?.label
                        : "Select student..."}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                    <Command>
                      <CommandInput placeholder="Search student..." />
                      <CommandList>
                        <CommandEmpty>No student found.</CommandEmpty>
                        <CommandGroup>
                          {participants.map((participant) => (
                            <CommandItem
                              key={participant.value}
                              value={participant.label}
                              onSelect={() => {
                                setSelectedUserId(participant.value)
                                setOpenUserSearch(false)
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  selectedUserId === participant.value ? "opacity-100" : "opacity-0"
                                )}
                              />
                              {participant.label}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
            )}
          </>
        )}

        {/* --- Amount Field (for everyone) --- */}
        <div className="space-y-2">
          <Label htmlFor="amount" className="text-white/80">Amount</Label>
          <Input
            id="amount"
            type="number"
            placeholder="e.g., 500"
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            min="0"
          />
        </div>

        {/* --- Submit Button --- */}
        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            method === 'online' ? 'Proceed to Payment Gateway' : 'Log Cash Payment'
          )}
        </Button>

        {method === 'online' && (
            <p className="text-xs text-center text-white/60">
              Note: Real payment gateway integration (Stripe/Razorpay) is the next step.
            </p>
        )}
      </form>
    </CardContent>
  )
}