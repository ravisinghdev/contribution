// app/dashboard/DashboardClientPage.tsx
"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Loader2, Plus, Mail, Camera, Calendar } from "lucide-react";
import { createClient } from "@/lib/supabase/client"; // <-- Uses the client helper
import { toast } from "react-hot-toast";

import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

// Define the props we're getting from the Server Page
interface DashboardClientPageProps {
  profile: {
    full_name: string;
  };
  role: string;
  contributions: {
    messages: number;
    photos: number;
    letters: number;
    xp: number;
  };
  activeFarewellId: number; // <-- The new prop
}

export function DashboardClientPage({
  profile,
  role,
  contributions,
  activeFarewellId, // <-- Accept the new prop
}: DashboardClientPageProps) {
  const quickActions = [
    { label: "Write a Letter 💌", icon: Mail, action: "letter" },
    { label: "Upload a Memory 📸", icon: Camera, action: "memory" },
    { label: "Send a Message 💬", icon: Plus, action: "message" },
    { label: "View Timeline 🪩", icon: Calendar, action: "timeline" },
  ];

  // --- Modal State and Logic ---
  const [openModal, setOpenModal] = useState<string | null>(null);
  const [modalContent, setModalContent] = useState("");
  const [modalSubject, setModalSubject] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAction = (type: string) => {
    setOpenModal(type);
  };

  const handleSubmitModal = async () => {
    setIsSubmitting(true);
    const supabase = createClient();
    let error = null;

    // --- THIS IS THE FIX ---
    // Use the prop instead of a hardcoded '1'
    const farewellId = activeFarewellId;

    if (openModal === "letter") {
      // This maps to our 'slams' table
      // TODO: We need a way to select the 'to_user_id'
      toast.error("Submitting letters isn't hooked up yet!");
      // { error } = await supabase.from('slams').insert({
      //   message: modalContent,
      //   to_user_id: 'UUID_OF_RECIPIENT',
      //   farewell_id: farewellId
      // });
    } else if (openModal === "message") {
      // This maps to our 'posts' (Memory Wall) table
      ({ error } = await supabase.from("posts").insert({
        content: modalContent,
        farewell_id: farewellId, // <-- Correct ID
      }));
    } else if (openModal === "memory") {
      // This maps to 'gallery_uploads'
      // This requires file upload, which is more complex
      toast.error("File upload isn't hooked up yet!");
    }

    if (error) {
      toast.error(error.message);
    } else if (openModal !== "memory" && openModal !== "letter") {
      toast.success("Submission successful!");
      setOpenModal(null);
      setModalContent("");
    }

    setIsSubmitting(false);
  };

  // This is your JSX, with the layout's background in mind
  return (
    <div className="space-y-10 text-white">
      {/* Header */}
      <motion.div
        className="relative overflow-hidden rounded-2xl p-8 bg-black/20 border border-white/20 backdrop-blur-md shadow-lg"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
          <div>
            <h1 className="text-3xl font-bold">
              Welcome back,{" "}
              <span className="text-pink-400">{profile.full_name}</span> 👋
            </h1>
            <p className="text-white/80 mt-1">
              Here’s your farewell world — full of messages, laughter &
              gratitude.
            </p>
            <Badge
              variant="secondary"
              className="mt-3 capitalize bg-pink-500/20 text-pink-300 border-pink-500/30"
            >
              {role.replace("_", " ")}
            </Badge>
          </div>
          <Sparkles className="absolute top-5 right-5 opacity-20 text-pink-400 animate-spin-slow" />
        </div>
      </motion.div>
      
      {/* Quick Actions */}
      <section>
        <h2 className="text-xl font-semibold mb-4">✨ Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {quickActions.map((item, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
            >
              <Card
                onClick={() => handleAction(item.action)}
                className="group cursor-pointer bg-black/20 hover:bg-black/40 backdrop-blur-lg border-white/20 text-center p-4 hover:shadow-lg transition-all"
              >
                <item.icon className="mx-auto w-6 h-6 mb-2 text-pink-400" />
                <p className="font-medium group-hover:text-pink-400 transition-colors text-white/90">
                  {item.label}
                </p>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>
      
      {/* Contribution Overview */}
      <section>
        <h2 className="text-xl font-semibold mb-4">📊 Your Contributions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { title: "Messages", value: contributions.messages },
            { title: "Photos", value: contributions.photos },
            { title: "Letters", value: contributions.letters },
            { title: "XP", value: contributions.xp + " pts" },
          ].map((item, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              <Card className="bg-black/20 hover:bg-black/30 border-white/20 backdrop-blur-md">
                <CardHeader>
                  <CardTitle className="text-base text-white/70">
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <motion.p
                    key={item.value}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="text-3xl font-bold text-white"
                  >
                    {item.value}
                  </motion.p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>
      
      {/* Announcements */}
      <section>
        <h2 className="text-xl font-semibold mb-4">📢 Announcements</h2>
        <Card className="bg-black/20 backdrop-blur-lg border-white/20">
          <CardContent className="space-y-3 text-sm mt-4 text-white/90">
            <p>🎤 Final Rehearsal — Friday 5PM</p>
            <p>🎞️ New Tribute Video Uploaded</p>
            <p>🎉 Awards Voting — Ends Tomorrow!</p>
          </CardContent>
        </Card>
      </section>
      
      {/* Role-Specific Section */}
      <section>
        <h2 className="text-xl font-semibold mb-4 capitalize">
          {role === "student"
            ? "🎓 Your Space"
            : role.includes("admin")
            ? "🛠️ Admin Panel"
            : "📚 Teacher’s Corner"}
        </h2>

        {role === "student" && (
          <Card className="bg-gradient-to-br from-pink-500/10 to-purple-600/10 backdrop-blur-md border-white/20">
            <CardContent className="mt-4 space-y-2 text-sm text-white/90">
              <p>💌 3 new farewell letters received!</p>
              <p>📷 5 new photos in your album.</p>
              <p>🪩 Tribute video uploaded!</p>
            </CardContent>
          </Card>
        )}

        {(role === "main_admin" || role === "parallel_admin") && (
          <Card className="bg-gradient-to-br from-blue-500/10 to-indigo-600/10 border-white/20">
            <CardContent className="mt-4 space-y-2 text-sm text-white/90">
              <p>📋 2 pending event approvals.</p>
              <p>💰 Budget tracker: 82% used.</p>
              <p>🧍‍♂️ New volunteer request received.</p>
            </CardContent>
          </Card>
        )}
      </section>
      
      {/* Footer */}
      <footer className="text-center pt-10 text-white/70 text-sm">
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          “Every goodbye holds a promise — the memories we made stay forever.”
          <br />
          <span className="text-pink-400 font-medium">— Class of 2025 💫</span>
        </motion.p>
      </footer>
      
      {/* Dynamic Modals */}
      <Dialog open={!!openModal} onOpenChange={() => setOpenModal(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {openModal === "letter"
                ? "Write a Letter 💌"
                : openModal === "memory"
                ? "Upload a Memory 📸"
                : openModal === "message"
                ? "Send a Message 💬"
                : "Timeline 🪩"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-3">
            {openModal === "letter" && (
              <>
                <Input placeholder="To (Name or @username)" />
                <Textarea
                  placeholder="Write your heartfelt farewell letter..."
                  value={modalContent}
                  onChange={(e) => setModalContent(e.target.value)}
                />
                <Button
                  className="w-full"
                  onClick={handleSubmitModal}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <Loader2 className="animate-spin" />
                  ) : (
                    "Send Letter"
                  )}
                </Button>
              </>
            )}

            {openModal === "memory" && (
              <>
                <Input type="file" />
                <Textarea
                  placeholder="Write a short caption..."
                  value={modalContent}
                  onChange={(e) => setModalContent(e.target.value)}
                />
                <Button
                  className="w-full"
                  onClick={handleSubmitModal}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <Loader2 className="animate-spin" />
                  ) : (
                    "Upload Memory"
                  )}
                </Button>
              </>
            )}

            {openModal === "message" && (
              <>
                <Textarea
                  placeholder="Write your short message for the memory wall..."
                  value={modalContent}
                  onChange={(e) => setModalContent(e.target.value)}
                />
                <Button
                  className="w-full"
                  onClick={handleSubmitModal}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <Loader2 className="animate-spin" />
                  ) : (
                    "Send Message"
                  )}
                </Button>
              </>
            )}

            {openModal === "timeline" && (
              <p className="text-center text-muted-foreground">
                🎉 Farewell Event — March 28
                <br />
                🏆 Voting ends in 2 days
                <br />
                🎬 Video Premiere — March 30
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}