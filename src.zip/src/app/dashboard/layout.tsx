import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { cookies, headers } from "next/headers";
import { SidebarProvider } from "@/components/dashboard/layout/SidebarContext";
import Navbar from "@/components/dashboard/layout/Navbar";
import Sidebar from "@/components/dashboard/layout/Sidebar";
import { AnimatedBackground } from "@/components/ui/AnimatedBackground";
import type { Database } from "@/lib/database.types";

export type Farewell = Database["public"]["Tables"]["farewells"]["Row"];

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // 1. Get cookies and path (no 'await')
  const cookieStore = await cookies();
  const headersList = await headers();
  const pathname = headersList.get("next-url") || "";

  // 2. Create the client (no 'await')
  const supabase = await createClient();

  // 3. Get Session ('await' is correct here)
  const {
    data: { session },
  } = await supabase.auth.getSession();
  if (!session) {
    redirect("/login"); // This is the ONLY redirect, for non-logged-in users
  }

  // 4. Fetch User Profile
  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, avatar_url")
    .eq("id", session.user.id)
    .single();

  const userProfile = profile || {
    full_name: session.user.email?.split("@")[0] || "User",
    avatar_url: null,
  };

  // 5. Fetch ALL farewells
  const { data: participations } = await supabase
    .from("farewell_participants")
    .select("farewells ( * )")
    .eq("user_id", session.user.id);

  const allFarewells: Farewell[] =
    (participations?.map((p) => p.farewells).filter(Boolean) as Farewell[]) ||
    [];

  // 6. --- REDIRECT LOGIC IS REMOVED ---
  // The pages themselves ('/dashboard/page.tsx' and
  // '/dashboard/welcome/page.tsx') will handle their own redirects.

  const hasNoFarewells = allFarewells.length === 0;

  // 7. Find the *active* farewell (only if they have one)
  let activeFarewell: Farewell | undefined;

  if (!hasNoFarewells) {
    const activeIdFromCookie = cookieStore.get("active_farewell_id")?.value;
    activeFarewell = allFarewells.find(
      (f) => f.id.toString() === activeIdFromCookie
    );

    // Default to the first one. We DO NOT set a cookie here.
    if (!activeFarewell) {
      activeFarewell = allFarewells[0];
    }
  }

  return (
    <SidebarProvider>
      <AnimatedBackground>
        <div className="h-screen flex flex-col">
          {/* If they have no farewells, render a blank shell */}
          {hasNoFarewells ? (
            <main className="h-screen w-full">{children}</main>
          ) : (
            /* If they have farewells, render the full UI */
            <>
              <Navbar
                user={userProfile}
                email={session.user.email || ""}
                allFarewells={allFarewells}
                activeFarewell={activeFarewell!}
              />
              <div className="flex flex-1 overflow-hidden pt-14">
                <Sidebar user={userProfile} />
                <main className="flex-1 overflow-y-auto sm:pl-64 text-white">
                  <div className="p-4 sm:p-8">{children}</div>
                </main>
              </div>
            </>
          )}
        </div>
      </AnimatedBackground>
    </SidebarProvider>
  );
}
