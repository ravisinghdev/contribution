// app/dashboard/welcome/page.tsx
'use client'

import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import { useState, useEffect, useTransition } from "react";
import { toast } from "react-hot-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"; // Re-import Tabs
import { Loader2, Users, Plus } from "lucide-react";
import { createFarewellAction, joinFarewellAction } from "../actions"; // Import both actions

export default function WelcomePage() {
  const router = useRouter();
  const supabase = createClient();
  const [isLoading, setIsLoading] = useState(true);
  
  // We now have two pending states
  const [isCreatePending, startCreateTransition] = useTransition();
  const [isJoinPending, startJoinTransition] = useTransition();

  // --- Gatekeeper Logic (no changes) ---
  useEffect(() => {
    const checkUserFarewells = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { count } = await supabase
          .from("farewell_participants")
          .select("id", { count: "exact" })
          .eq("user_id", user.id);

        if (count && count > 0) {
          router.push("/dashboard");
        } else {
          setIsLoading(false);
        }
      } else {
        router.push('/login');
      }
    };
    checkUserFarewells();
  }, [supabase, router]);
  // --- End of Gatekeeper ---

  // State for both forms
  const [farewellName, setFarewellName] = useState("");
  const [farewellYear, setFarewellYear] = useState(new Date().getFullYear() + 1);
  const [joinCode, setJoinCode] = useState("");

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (farewellName.length < 5) {
      toast.error("Farewell name must be at least 5 characters long.");
      return;
    }

    startCreateTransition(async () => {
      const result = await createFarewellAction(farewellName, farewellYear);
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success("Farewell created! Redirecting...");
        router.push("/dashboard"); // The action revalidated, so a simple push works
      }
    });
  };

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (joinCode.length < 8) {
      toast.error("Invite code must be 8 characters.");
      return;
    }

    startJoinTransition(async () => {
      const result = await joinFarewellAction(joinCode);
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success("Successfully joined farewell! Redirecting...");
        router.push("/dashboard");
      }
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-center">
            Welcome to the Farewell App
          </CardTitle>
          <CardDescription className="text-center pt-2">
            You aren't part of a farewell event yet.
            <br />
            Join an existing one or create a new one to get started.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Re-introducing Tabs */}
          <Tabs defaultValue="join">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="join">
                <Users className="w-4 h-4 mr-2" /> Join Farewell
              </TabsTrigger>
              <TabsTrigger value="create">
                <Plus className="w-4 h-4 mr-2" /> Create New
              </TabsTrigger>
            </TabsList>
            
            {/* --- JOIN TAB --- */}
            <TabsContent value="join">
              <form onSubmit={handleJoin} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="invite-code">8-Digit Invite Code</Label>
                  <Input
                    id="invite-code"
                    placeholder="a1b2c3d4"
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value)}
                    maxLength={8}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isJoinPending}>
                  {isJoinPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    'Join Event'
                  )}
                </Button>
              </form>
            </TabsContent>
            
            {/* --- CREATE TAB --- */}
            <TabsContent value="create">
              <form onSubmit={handleCreate} className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="farewell-name">Farewell Name</Label>
                  <Input
                    id="farewell-name"
                    placeholder="e.g., Farewell for Class of 2025"
                    value={farewellName}
                    onChange={(e) => setFarewellName(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="farewell-year">Event Year</Label>
                  <Input
                    id="farewell-year"
                    type="number"
                    placeholder="e.g., 2025"
                    value={farewellYear}
                    onChange={(e) => setFarewellYear(parseInt(e.target.value))}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isCreatePending}>
                  {isCreatePending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    'Create Event'
                  )}
                </Button>
              </form>
            </TabsContent>
          </Tabs>

        </CardContent>
      </Card>
    </div>
  );
}