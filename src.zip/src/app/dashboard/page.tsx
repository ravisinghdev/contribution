// app/dashboard/page.tsx
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { DashboardClientPage } from "./DashboardClientPage";
import { cookies } from "next/headers";

export default async function DashboardPage() {
  const cookieStore = await cookies();
  const supabase = await createClient();

  // 1. Get User
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    redirect("/login");
  }

  // 2. --- GATEKEEPER LOGIC (Checks if user has any farewells) ---
  const { data: participations } = await supabase
    .from("farewell_participants")
    .select("farewell_id, role")
    .eq("user_id", user.id);

  if (!participations || participations.length === 0) {
    redirect("/dashboard/welcome");
  }

  // 3. Determine the *current* active farewell
  let currentFarewellId: number;
  let currentRole: string;

  const activeIdFromCookie = cookieStore.get("active_farewell_id")?.value;
  const validCookieParticipation = activeIdFromCookie
    ? participations.find(
        (p) => p.farewell_id.toString() === activeIdFromCookie
      )
    : undefined;

  if (validCookieParticipation) {
    currentFarewellId = validCookieParticipation.farewell_id;
    currentRole = validCookieParticipation.role;
  } else {
    currentFarewellId = participations[0].farewell_id;
    currentRole = participations[0].role;
  }

  // 4. --- SIMPLIFIED FETCH: Get Profile and Role in one query ---
  const [userRoleProfileRes, postsRes, galleryRes, slamsRes] =
    await Promise.all([
      // Query the new view to get the profile and the role together
      supabase
        .from("user_roles_view")
        .select("full_name, role")
        .eq("user_id", user.id)
        .eq("farewell_id", currentFarewellId)
        .single(),

      // Fetch contribution counts
      supabase
        .from("posts")
        .select("id", { count: "exact" })
        .eq("user_id", user.id)
        .eq("farewell_id", currentFarewellId),
      supabase
        .from("gallery_uploads")
        .select("id", { count: "exact" })
        .eq("user_id", user.id)
        .eq("farewell_id", currentFarewellId),
      supabase
        .from("slams")
        .select("id", { count: "exact" })
        .eq("from_user_id", user.id)
        .eq("farewell_id", currentFarewellId),
    ]);
  // 5. Process the data

  const profile = {
    full_name:
      userRoleProfileRes.data?.full_name || user.email?.split("@")[0] || "User",
  };
  const role = userRoleProfileRes.data?.role || currentRole; // Use the role from the view, default to the one from participations

  const contributions = {
    messages: postsRes.count || 0,
    photos: galleryRes.count || 0,
    letters: slamsRes.count || 0,
    xp:
      (postsRes.count || 0) * 10 +
      (galleryRes.count || 0) * 20 +
      (slamsRes.count || 0) * 15,
  };

  // 6. Pass data to the Client Component
  return (
    <DashboardClientPage
      profile={profile}
      role={role}
      contributions={contributions}
      activeFarewellId={currentFarewellId}
    />
  );
}
