"use client";

import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import {
  Bell,
  AlertTriangle,
  Plus,
  Search,
  Loader2,
  Clock,
} from "lucide-react";
import { toast } from "react-hot-toast";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";

export interface Announcement {
  id: number;
  title: string;
  content: string;
  is_urgent: boolean;
  time: string;
  author: string;
}

interface Props {
  announcements: Announcement[];
  isAdmin: boolean;
  currentFarewellId: number;
  currentUserId: string;
}

export function AnnouncementsClientPage({
  announcements,
  isAdmin,
  currentFarewellId,
  currentUserId,
}: Props) {
  const router = useRouter();
  const supabase = createClient();

  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [isUrgent, setIsUrgent] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState<"all" | "urgent" | "general">("all");

  // --- filter logic
  const filtered = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return announcements
      .filter((a) => {
        if (filter === "urgent" && !a.is_urgent) return false;
        if (filter === "general" && a.is_urgent) return false;
        return (
          a.title.toLowerCase().includes(term) ||
          a.content.toLowerCase().includes(term)
        );
      })
      .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());
  }, [announcements, filter, searchTerm]);

  // --- submit new announcement
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim())
      return toast.error("Please fill out all fields.");

    setIsSubmitting(true);
    const { error } = await supabase.from("announcements").insert({
      farewell_id: currentFarewellId,
      user_id: currentUserId,
      title: newTitle,
      content: newContent,
      is_urgent: isUrgent,
    });

    if (error) toast.error(error.message);
    else {
      toast.success("Announcement posted 🎉");
      setOpen(false);
      setNewTitle("");
      setNewContent("");
      setIsUrgent(false);
      router.refresh();
    }
    setIsSubmitting(false);
  };

  // --- reusable item
  const AnnouncementItem = ({ a }: { a: Announcement }) => (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      className="rounded-xl border border-white/10 bg-gradient-to-br from-zinc-900/40 to-zinc-800/20 p-4 backdrop-blur-md hover:shadow-lg transition-all"
    >
      <div className="flex justify-between items-start mb-2">
        <div className="flex items-center gap-3">
          {a.is_urgent ? (
            <AlertTriangle className="text-red-400 h-5 w-5 animate-pulse" />
          ) : (
            <Bell className="text-yellow-400 h-5 w-5" />
          )}
          <h3 className="font-semibold text-lg">{a.title}</h3>
        </div>
        <Badge
          variant={a.is_urgent ? "destructive" : "secondary"}
          className="text-[10px] tracking-wide uppercase"
        >
          {a.is_urgent ? "Urgent" : "General"}
        </Badge>
      </div>

      <p className="text-sm text-zinc-200 leading-relaxed mb-3 whitespace-pre-wrap">
        {a.content}
      </p>

      <div className="flex justify-between text-xs text-zinc-500 border-t border-white/10 pt-2">
        <span>{a.author}</span>
        <span className="flex items-center gap-1">
          <Clock className="h-3 w-3" />
          {format(new Date(a.time), "MMM d, hh:mm a")}
        </span>
      </div>
    </motion.div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative w-full mx-auto max-w-4xl px-3 sm:px-6 space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <Bell className="h-7 w-7 text-yellow-400" />
          <h1 className="text-3xl font-semibold bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent">
            Announcements
          </h1>
        </div>

        {isAdmin && (
          <Button
            onClick={() => setOpen(true)}
            className="bg-gradient-to-r from-pink-500 to-purple-500 text-white hover:opacity-90"
          >
            <Plus className="h-4 w-4 mr-2" />
            New
          </Button>
        )}
      </div>

      {/* Search + Filter */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative w-full sm:w-1/2">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 h-4 w-4" />
          <Input
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 bg-zinc-900/40 border-zinc-700/50 text-white placeholder:text-zinc-500"
          />
        </div>

        <div className="flex gap-2 flex-wrap sm:ml-auto">
          {(["all", "urgent", "general"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={`px-3 py-1 text-xs rounded-full border transition-all ${
                filter === t
                  ? t === "urgent"
                    ? "border-red-500 bg-red-500/20 text-red-400"
                    : "border-pink-500 bg-pink-500/20 text-pink-400"
                  : "border-white/10 text-zinc-400 hover:text-white"
              }`}
            >
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <AnimatePresence>
        {filtered.length === 0 ? (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center text-zinc-400 py-12"
          >
            No announcements yet 🚀
          </motion.p>
        ) : (
          <div className="grid gap-4">
            {filtered.map((a) => (
              <AnnouncementItem key={a.id} a={a} />
            ))}
          </div>
        )}
      </AnimatePresence>

      {/* Floating Add Button (mobile only) */}
      {isAdmin && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-6 right-6 sm:hidden p-4 rounded-full bg-gradient-to-r from-pink-500 to-purple-500 shadow-lg hover:scale-105 transition-transform"
        >
          <Plus className="text-white h-6 w-6" />
        </button>
      )}

      {/* Modal */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md bg-zinc-900/80 backdrop-blur-lg border-zinc-800 text-white">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold">
              Create Announcement
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              placeholder="Title"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="bg-zinc-900/60 border-zinc-700 text-white"
            />
            <Textarea
              placeholder="Write something inspiring..."
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              rows={5}
              className="bg-zinc-900/60 border-zinc-700 text-white"
            />
            <label className="flex items-center gap-2 text-sm text-red-400">
              <Checkbox
                checked={isUrgent}
                onCheckedChange={(v) => setIsUrgent(!!v)}
              />
              Mark as urgent
            </label>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white"
            >
              {isSubmitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                "Post"
              )}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
