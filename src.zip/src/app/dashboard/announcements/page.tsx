// app/dashboard/announcements/page.tsx
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import {
  AnnouncementsClientPage,
  Announcement,
} from "./AnnouncementsClientPage";
import { toast } from "react-hot-toast";

// Define the data type for the announcement list (used internally for mapping)
interface AnnouncementWithProfile extends Announcement {
  // The aliased user_id link that the SQL returns
  user_id: { full_name: string } | null;
}

export default async function AnnouncementsPage() {
  const supabase = await createClient();

  // 1. Authentication and Gatekeeper
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: participation } = await supabase
    .from("farewell_participants")
    .select("role, farewell_id")
    .eq("user_id", user.id)
    .limit(1)
    .single();

  if (!participation) redirect("/dashboard/welcome");

  const { role, farewell_id: currentFarewellId } = participation;
  const isAdmin = role === "main_admin" || role === "parallel_admin";
  const currentUserId = user.id; // <-- The ID we pass for insertion

  // 2. Fetch Announcements
  // The TypeScript error is solved because 'announcements' is now in lib/database.types.ts
  const { data: announcementsData, error } = await (supabase as any)
    .from("announcements")
    // Use the aliased join to get the author's name
    .select(
      `
        id, title, content, is_urgent, created_at,
        user_id:profiles ( full_name ) 
    `
    )
    .eq("farewell_id", currentFarewellId)
    .order("created_at", { ascending: false });

  if (error) console.error("Error fetching announcements:", error);

  // 3. Prepare Data
  const announcements: Announcement[] = (
    (announcementsData as any[]) || []
  ).map((a) => ({
    id: a.id,
    title: a.title,
    content: a.content,
    is_urgent: a.is_urgent,
    time: a.created_at,
    author: a.user_id?.full_name || "System",
  }));

  // 4. Pass data to Client Component
  return (
    <AnnouncementsClientPage
      announcements={announcements}
      isAdmin={isAdmin}
      currentFarewellId={currentFarewellId}
      currentUserId={currentUserId} // <-- Passed for the NOT NULL constraint fix
    />
  );
}
