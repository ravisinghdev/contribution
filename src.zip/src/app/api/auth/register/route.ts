import { registerUser } from "@/lib/authService";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const reqBody = await req.json()
    const { email, password, metadata } = reqBody;
    const { user } = await registerUser({ email, password, metadata });
    return NextResponse.json({ user,
        message: "Registration successful! Check email for verification."}, {status: 200})
  } catch (err: any) {
   return NextResponse.json({error: err.message}, {status: 400})
  }
}
