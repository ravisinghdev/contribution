import { NextRequest, NextResponse } from "next/server";
import { loginUser } from "@/lib/authService";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required." },
        { status: 400 }
      );
    }

    // Call loginUser
    const { accessToken, refreshToken, user, roles, session } = await loginUser({ email, password });

    // Return full data
    return NextResponse.json(
      { accessToken, refreshToken, user, roles, session },
      { status: 200 }
    );
  } catch (err: any) {
    console.error(err);
    return NextResponse.json(
      { error: err.message || "Invalid email or password" },
      { status: 401 }
    );
  }
}
