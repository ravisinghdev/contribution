import { NextApiRequest, NextApiResponse } from "next";
import { verifyEmailToken } from "@/lib/authService";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { token } = await req.json();
    await verifyEmailToken(token);
    return NextResponse.json({message: "Email verified successfully"}, {status: 200})
  } catch (err: any) {
    return NextResponse.json({ error: err.message });
  }
}
