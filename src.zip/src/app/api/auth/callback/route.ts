import { createClient } from "@/lib/supabase/server"; // Our server client
import { NextResponse } from "next/server";
import { NextRequest } from "next/server";

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");

  // 'next' is an optional redirect URL to send the user to after auth
  const next = searchParams.get("next") || "/dashboard";

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      // On successful auth, redirect to the 'next' URL or home page
      return NextResponse.redirect(`${origin}${next}`);
    }
  }

  // If there's an error or no code, redirect to an error page or login
  console.error("Auth callback error");
  const errorUrl = new URL("/login?error=true", origin);
  return NextResponse.redirect(errorUrl);
}
