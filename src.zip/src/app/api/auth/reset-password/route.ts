import { NextApiRequest, NextApiResponse } from "next";
import { resetPassword } from "@/lib/authService";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { token, newPassword } = await req.json();
    if (!token || !newPassword)
      return NextResponse.json({ error: "Token and new password required" });

    await resetPassword(token, newPassword);
    return NextResponse.json(
      { message: "Password reset successfully" },
      { status: 200 }
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message });
  }
}
