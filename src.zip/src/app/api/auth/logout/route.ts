
import { logout } from "@/lib/authService";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { sessionId } = await req.json();
    await logout(sessionId);
    return NextResponse.json({message: "Logout successfully"}, {status: 200})
  } catch (err: any) {
    return NextResponse.json({error: err.message}, {status: 400})
  }
}
