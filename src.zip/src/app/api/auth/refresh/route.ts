import { refreshToken } from "@/lib/authService";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { refreshToken: token } = await req.json();
    const { accessToken, refreshToken: newRefreshToken } = await refreshToken(
      token
    );
    return NextResponse.json({ accessToken, refreshToken: newRefreshToken }, {status: 200})
  } catch (err: any) {
    return NextResponse.json({error: err.message})
  }
}
