import { AuthForm } from "@/components/auth/AuthForm";
import { createClient } from "@/lib/supabase/server"; // Our *server* client!
import { redirect } from "next/navigation";

export default async function LoginPage() {
  const supabase = await createClient();

  // Check if the user is already logged in
  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (session) {
    // If logged in, redirect them to the main page (or a dashboard)
    redirect("/dashboard");
  }

  // If not logged in, show the reusable auth form
  return (
    <div className="flex items-center justify-center min-h-screen p-4">
      <AuthForm />
    </div>
  );
}
