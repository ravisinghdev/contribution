'use client'

import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useSearchParams } from 'next/navigation'
import { toast } from 'react-hot-toast'

export default function CheckEmailPage() {
  const searchParams = useSearchParams()
  const email = searchParams.get('email')
  const supabase = createClient()

  const handleResend = async () => {
    if (!email) {
      toast.error('No email found. Please go back and sign up again.')
      return
    }

    const { error } = await supabase.auth.resend({
      type: 'signup',
      email: email,
    })

    if (error) {
      toast.error(error.message)
    } else {
      toast.success('Confirmation email resent!')
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">Check your inbox</CardTitle>
          <CardDescription>
            We've sent a confirmation link to{' '}
            <strong className="text-foreground">{email || 'your email'}</strong>.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Click the link in the email to finish signing up. If you don't
            see it, please check your spam folder.
          </p>
          <Button onClick={handleResend} className="w-full mt-6">
            Didn't get an email? Resend
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}