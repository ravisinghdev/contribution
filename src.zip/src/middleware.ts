import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/middleware";

export async function middleware(request: NextRequest) {
  // This is the most critical line.
  // We MUST destructure { supabase, response } from the helper.
  // Your error was likely caused by not doing this.
  const { supabase, response } = createClient(request);

  // Now `supabase.auth.getSession()` will work perfectly.
  await supabase.auth.getSession();

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
};
