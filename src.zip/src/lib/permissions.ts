// Define all allowed roles as a type
export type UserRole = "main_admin" | "parallel_admin" | "student";

// Define your permission structure
export const RolePermissions = {
  main_admin: {
    canPostAnnouncement: true,
    canDeleteAnnouncement: true,
    canManageDuties: true,
    canApproveSubmissions: true,
  },
  parallel_admin: {
    canPostAnnouncement: true,
    canDeleteAnnouncement: false,
    canManageDuties: false,
    canApproveSubmissions: true,
  },
  student: {
    canPostAnnouncement: false,
    canDeleteAnnouncement: false,
    canManageDuties: false,
    canApproveSubmissions: false,
  },
} as const;

// Infer types dynamically from the above object
type RoleMap = typeof RolePermissions;
type PermissionKey = keyof RoleMap["main_admin"];

// ✅ Safe helper function
export function can(
  role: UserRole,
  permission: PermissionKey
): boolean {
  return RolePermissions[role][permission];
}
